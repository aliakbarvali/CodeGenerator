


!function (e) { "function" == typeof define && define.amd ? define(["kendo.core.min"], e) : e() }
    (function () {
        !function (e, t) {
            kendo.ui.FlatColorPicker && (kendo.ui.FlatColorPicker.prototype.options.messages = e.extend(!0,
                kendo.ui.FlatColorPicker.prototype.options.messages, { apply: "تایید", cancel: "انصراف" }
            )), kendo.ui.ColorPicker && (kendo.ui.ColorPicker.prototype.options.messages = e.extend(!0,
                kendo.ui.ColorPicker.prototype.options.messages, { apply: "تایید", cancel: "انصراف" }
            )), kendo.ui.ColumnMenu && (kendo.ui.ColumnMenu.prototype.options.messages = e.extend(!0,
                kendo.ui.ColumnMenu.prototype.options.messages,
                {
                    sortAscending: "مرتب سازی صعودی", sortDescending: "مرتب سازی نزولی", filter: "فیلتر", columns: "ستون ها", done: "تمام",
                    settings: "تنظیمات ستون ها", lock: "بستن", unlock: "باز کردن"
                }
            )), kendo.ui.Editor && (kendo.ui.Editor.prototype.options.messages = e.extend(!0, kendo.ui.Editor.prototype.options.messages, {
                bold: "Bold", italic: "Italic", underline: "Underline", strikethrough: "Strikethrough", superscript: "Superscript", subscript: "Subscript",
                justifyCenter: "Center text", justifyLeft: "متن چپ چین", justifyRight: "متن راست چین", justifyFull: "Justify",
                insertUnorderedList: "درج لیست نامرتب", insertOrderedList: "درج لیست مرتب", indent: "Indent", outdent: "Outdent",
                createLink: "درج هایپرلینک", unlink: "حذف هایپرلینک", insertImage: "درج تصویر", insertFile: "درج فایل",
                insertHtml: "درج متن آماده", viewHtml: "مشاهده HTML", fontName: "Select font family", fontNameInherit: "(inherited font)",
                fontSize: "Select font size", fontSizeInherit: "(inherited size)", formatBlock: "فرمت", formatting: "Format", foreColor: "Color",
                backColor: "Background color", style: "Styles", emptyFolder: "Empty Folder", uploadFile: "آپلود", orderBy: "مرتب‌سازی:",
                orderBySize: "اندازه", orderByName: "نام", invalidFileType: 'فایل انتخابی "{0}" معتبر نیست. فایلهای معتبر {1}.',
                deleteFile: 'آیا از حذف "{0}" اطمینان دارید؟',
                overwriteFile: 'فایل "{ 0}" در این مسیر موجو است. جایگزین شود؟',
                directoryNotFound: "فولدری با این نام یافت نشد.", imageWebAddress: "آدرس وب", imageAltText: "متن جایگزین",
                imageWidth: "عرض(px)", imageHeight: "ارتفاع(px)", fileWebAddress: "آدرس وب", fileTitle: "عنوان",
                linkWebAddress: "آدرس وب", linkText: "متن", linkToolTip: "ToolTip", linkOpenInNewWindow: "باز شدن لینک در صفحه جدید",
                dialogUpdate: "بروزرسانی", dialogInsert: "درج", dialogButtonSeparator: "یا", dialogCancel: "انصراف", createTable: "ایجاد جدول",
                addColumnLeft: "افزودن ستون در چپ", addColumnRight: "افزودن ستون در راست", addRowAbove: "افزودن سطر در بالا",
                addRowBelow: "افزودن سطر در پایین", deleteRow: "حذف سطر", deleteColumn: "حذف ستون"
            })), kendo.ui.FileBrowser && (kendo.ui.FileBrowser.prototype.options.messages = e.extend(!0,
                kendo.ui.FileBrowser.prototype.options.messages, {
                    uploadFile: "بارگزاری", orderBy: "مرتب سازی بر اساس", orderByName: "نام", orderBySize: "اندازه",
                    directoryNotFound: "فولدر مورد نظر پیدا نشد", emptyFolder: "فولدر خالی", deleteFile: 'آیا از حذف "{0}" اطمینان دارید؟',
                    invalidFileType: 'انتخاب فایل با پسوند "{ 0}" امکانپذیر نیست. پسوندهای پشیتبانی شده: {1}',
                    overwriteFile: 'فایل با نام "{0}" در فولدر انتخابی وجود دارد. آیا می خواهید آن را بازنویسی کنید؟',
                    dropFilesHere: "فایل را به اینجا بکشید", search: "جستجو"
                })), kendo.ui.FilterCell && (kendo.ui.FilterCell.prototype.options.messages = e.extend(!0, kendo.ui.FilterCell.prototype.options.messages,
                    { isTrue: "درست باشد", isFalse: "درست نباشد", filter: "فیلتر", clear: "پاک کردن", operator: "عملگر" }
                )), kendo.ui.FilterCell && (kendo.ui.FilterCell.prototype.options.operators = e.extend(!0, kendo.ui.FilterCell.prototype.options.operators,
                    {
                        string: {
                            eq: "برابر باشد با", neq: "برابر نباشد با", startswith: "شروع شود با", contains: "شامل باشد", doesnotcontain: "شامل نباشد",
                            endswith: "پایان یابد با"
                        }
                        , number: {
                            eq: "برابر باشد با", neq: "برابر نباشد با", gte: "برابر یا بزرگتر باشد از", gt: "بزرگتر باشد از",
                            lte: "کمتر و یا برابر باشد با", lt: "کمتر باشد از"
                        }
                        , date: {
                            eq: "برابر باشد با", neq: "برابر نباشد با", gte: "بعد از یا هم زمان باشد با", gt: "بعد از",
                            lte: "قبل از یا هم زمان باشد با", lt: "قبل از"
                        }
                        , enums: { eq: "برابر باشد با", neq: "برابر نباشد با" }
                    }
                )), kendo.ui.FilterMenu && (kendo.ui.FilterMenu.prototype.options.messages = e.extend(!0, kendo.ui.FilterMenu.prototype.options.messages,
                    {
                        info: "ردیف های را نشان بده که:", isTrue: "درست باشد", isFalse: "درست نباشد", filter: "فیلتر", clear: "پاک کردن", and: "و",
                        or: "یا", selectValue: "-انتخاب مقدار-", operator: "عملگر", value: "مقدار", cancel: "انصراف"
                    }
                )), kendo.ui.FilterMenu && (kendo.ui.FilterMenu.prototype.options.operators = e.extend(!0, kendo.ui.FilterMenu.prototype.options.operators,

                    {
                        string: {
                            eq: "برابر باشد با", neq: "برابر نباشد با", startswith: "شروع شود با", contains: "شامل باشد",
                            doesnotcontain: "شامل نباشد", endswith: "پایان یابد با"
                        }
                        , number: {
                            eq: "برابر باشد با", neq: "برابر نباشد با", gte: "برابر یا بزرگتر باشد از", gt: "بزرگتر باشد از",
                            lte: "کمتر و یا برابر باشد با", lt: "کمتر باشد از"
                        }
                        , date: {
                            eq: "برابر باشد با", neq: "برابر نباشد با", gte: "بعد از یا هم زمان باشد با", gt: "بعد از",
                            lte: "قبل از یا هم زمان باشد با", lt: "قبل از"
                        }
                        , enums: { eq: "برابر باشد با", neq: "برابر نباشد با" }
                    }
                )), kendo.ui.FilterMultiCheck && (kendo.ui.FilterMultiCheck.prototype.options.messages = e.extend(!0,
                    kendo.ui.FilterMultiCheck.prototype.options.messages, { checkAll: "انتخاب همه", clear: "پاک کردن", filter: "فیلتر" }
                )), kendo.ui.Gantt && (kendo.ui.Gantt.prototype.options.messages = e.extend(!0, kendo.ui.Gantt.prototype.options.messages, {
                    actions: {
                        addChild: "اضافه کردن فرزند", append: "اضافه کردن کار", insertAfter: "اضافه کن زیر", insertBefore: "اضافه کن بالای",
                        pdf: "گرفتن خروجی PDF"
                    }
                    , cancel: "انصراف", deleteDependencyWindowTitle: "حذف رابطه", deleteTaskWindowTitle: "حذف کار", destroy: "حذف",
                    editor: {
                        assingButton: "ارجاع دادن", editorTitle: "کار", end: "پایان", percentComplete: "پیشرفت", resources: "منابع",
                        resourcesEditorTitle: "منابع", resourcesHeader: "منابع", start: "شروع", title: "عنوان", unitsHeader: "واحدها"
                    }
                    , save: "ذخیره", views: { day: "روز", end: "پایان", month: "ماه", start: "شروع", week: "هفته", year: "سال" }
                }
                )), kendo.ui.Grid && (kendo.ui.Grid.prototype.options.messages = e.extend(!0, kendo.ui.Grid.prototype.options.messages, {
                    commands: {
                        cancel: "انصراف", canceledit: "انصراف", create: "اضافه کردن ردیف جدید", destroy: "حذف", edit: "ویرایش",
                        excel: "خروجی Excel", pdf: "خروجی PDF", save: "ذخیره", select: "انتخاب", update: "ذخیره"
                    }
                    , editable: { cancelDelete: "انصراف", confirmation: "آیا از حذف این ردیف مطمئنید؟", confirmDelete: "حذف" }
                    , noRecords: "اطلاعاتی وجود ندارد"
                }
                )), kendo.ui.Groupable && (kendo.ui.Groupable.prototype.options.messages = e.extend(!0, kendo.ui.Groupable.prototype.options.messages,
                    { empty: "برای گروه بندی بر اساس یک ستون، عنوان ستون را به اینجا بکشید" }
                )), kendo.ui.NumericTextBox && (kendo.ui.NumericTextBox.prototype.options = e.extend(!0, kendo.ui.NumericTextBox.prototype.options,
                    { upArrowText: "اضافه کردن", downArrowText: "کم کردن" }
                )), kendo.ui.Pager && (kendo.ui.Pager.prototype.options.messages = e.extend(!0, kendo.ui.Pager.prototype.options.messages, {
                    allPages: "همه", display: "ردیف {0} تا {1} از {2} ردیف", empty: "ردیفی برای نمایش وجود ندارد", page: "صفحه", of: "از { 0}",
                    itemsPerPage: "ردیف های هر صفحه", first: "برو به صفحه اول", previous: "برو به صفحه قبل", next: "برو به صفحه بعد",
                    last: "برو به صفحه آخر", refresh: "بارگزاری مجدد", morePages: "صفحات بیشتر"
                })), kendo.ui.PivotGrid && (kendo.ui.PivotGrid.prototype.options.messages = e.extend(!0, kendo.ui.PivotGrid.prototype.options.messages,
                    { measureFields: "Drop Data Fields Here", columnFields: "Drop Column Fields Here", rowFields: "Drop Rows Fields Here" }
                )), kendo.ui.PivotFieldMenu && (kendo.ui.PivotFieldMenu.prototype.options.messages = e.extend(!0,
                    kendo.ui.PivotFieldMenu.prototype.options.messages, {
                        info: "Show items with value that:", filterFields: "Fields Filter", filter: "Filter", include: "Include Fields...",
                        title: "Fields to include",
                        clear: "انصراف", ok: "تایید", cancel: "انصراف", operators: {
                            contains: "Contains", doesnotcontain: "Does not contain",
                            startswith: "Starts with", endswith: "Ends with", eq: "Is equal to", neq: "Is not equal to"
                        }
                    }
                )), kendo.ui.RecurrenceEditor && (kendo.ui.RecurrenceEditor.prototype.options.messages = e.extend(!0,
                    kendo.ui.RecurrenceEditor.prototype.options.messages, {
                        frequencies: { never: "هیچ وقت", hourly: "ساعتی", daily: "روزانه", weekly: "هفتگی", monthly: "ماهانه", yearly: "سالیانه" }
                        , hourly: { repeatEvery: "تکرار کن هر: ", interval: " ساعت" }
                        , daily: { repeatEvery: "تکرار کن هر: ", interval: " روز" }
                        , weekly: { interval: " هفته", repeatEvery: "تکرار کن هر: ", repeatOn: "تکرار کن در: " }
                        , monthly: { repeatEvery: "تکرار کن هر: ", repeatOn: "تکرار کن در: ", interval: " ماه", day: "روز " }
                        , yearly: { repeatEvery: "تکرار کن هر: ", repeatOn: "تکرار کن در: ", interval: " سال", of: " از " }
                        , end: { label: "پایان:", mobileLabel: "پایان", never: "هیچ وقت", after: "بعد از ", occurrence: " دفعات وقوع", on: "در " }
                        , offsetPositions: { first: "اول", second: "دوم", third: "سوم", fourth: "چهارم", last: "آخر" }
                        , weekdays: { day: "روز", weekday: "روز هفته", weekend: "پایان هفته" }
                    }
                )), kendo.ui.Scheduler && (kendo.ui.Scheduler.prototype.options.messages = e.extend(!0, kendo.ui.Scheduler.prototype.options.messages, {
                    allDay: "all day", date: "Date", event: "Event", time: "Time", showFullDay: "Show full day",
                    showWorkDay: "Show business hours", today: "Today", save: "Save", cancel: "Cancel", destroy: "Delete",
                    deleteWindowTitle: "Delete event", ariaSlotLabel: "Selected from {0:t} to { 1: t }",
                    ariaEventLabel: "{ 0} on { 1: D } at { 2: t }", editable: { confirmation: "Are you sure you want to delete this event?" }
                    , views: { day: "Day", week: "Week", workWeek: "Work Week", agenda: "Agenda", month: "Month" }
                    , recurrenceMessages: {
                        deleteWindowTitle: "Delete Recurring Item", deleteWindowOccurrence: "Delete current occurrence",
                        deleteWindowSeries: "Delete the series", editWindowTitle: "Edit Recurring Item", editWindowOccurrence: "Edit current occurrence",
                        editWindowSeries: "Edit the series", deleteRecurring: "Do you want to delete only this event occurrence or the whole series?",
                        editRecurring: "Do you want to edit only this event occurrence or the whole series?"
                    }
                    , editor: {
                        title: "عنوان", start: "شروع", end: "پایان", allDayEvent: "All day event", description: "توضیحات", repeat: "تکرار",
                        timezone: " ", startTimezone: "Start timezone", endTimezone: "End timezone", separateTimezones: "Use separate start and end time zones",

                        timezoneEditorTitle: "Timezones", timezoneEditorButton: "Time zone", timezoneTitle: "Time zones", noTimezone: "No timezone",
                        editorTitle: "Event"
                    }
                }
                )), kendo.ui.Slider && (kendo.ui.Slider.prototype.options = e.extend(!0, kendo.ui.Slider.prototype.options, {
                    increaseButtonTitle: "افزایش",
                    decreaseButtonTitle: "کاهش"
                }
                )), kendo.ui.TreeList && (kendo.ui.TreeList.prototype.options.messages = e.extend(!0, kendo.ui.TreeList.prototype.options.messages, {
                    noRows: "ردیفی برای نمایش موجود نیست", loading: "در حال بارگزاری...", requestFailed: "شکست در انجام درخواست.", retry: "تلاش مجدد",
                    commands: {
                        edit: "ویرایش", update: "ذخیره", canceledit: "انصراف", create: "درج ردیف جدید", createchild: "درج گره جدید",
                        destroy: "حذف", excel: "خروجی Excel", pdf: "خروجی PDF"
                    }
                }
                )), kendo.ui.TreeView && (kendo.ui.TreeView.prototype.options.messages = e.extend(!0, kendo.ui.TreeView.prototype.options.messages,
                    { loading: "در حال بارگزاری...", requestFailed: "شکست در انجام درخواست.", retry: "تلاش مجدد" }
                )), kendo.ui.Upload && (kendo.ui.Upload.prototype.options.localization = e.extend(!0, kendo.ui.Upload.prototype.options.localization,
                    {
                        select: "انتخاب فایل(ها)...", cancel: "انصراف", retry: "تلاش مجدد", remove: "حذف", uploadSelectedFiles: "بارگزاری فایل(ها)",
                        dropFilesHere: "فایل(ها) را برای بارگزاری به اینجا بکشید", statusUploading: "در حال بارگزاری", statusUploaded: "پایان بارگزاری",
                        statusWarning: "هشداد", statusFailed: "خطا در بارگزاری", headerStatusUploading: "در حال بارگزاری...",
                        headerStatusUploaded: "اتمام بارگزاری"
                    }
                )), kendo.ui.Validator && (kendo.ui.Validator.prototype.options.messages = e.extend(!0, kendo.ui.Validator.prototype.options.messages, {
                    required: "{0} اجباری است", pattern: "{ 0} معتبر نیست", min: "{ 0} باید بزرگتر یا برابر باشد با { 1}",
                    max: "{ 0} باید کوچکتر یا برابر باشد با { 1}", step: "{ 0} معتبر نیست", email: "{ 0} یک ایمیل معتبر نیست",
                    url: "{ 0} آدرس وب سایت معتبر نیست", date: "{ 0} تاریخ معتبر نیست", dateCompare: "تاریخ پایان باید برابر یا بعد از تاریخ آغاز باشد"
                }
                ))
        }
            (window.kendo.jQuery)
    }
    );
//# sourceMappingURL=kendo.messages.fa-IR.min.js.map
